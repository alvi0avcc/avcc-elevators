import React from 'react';
import MenuApp from './js/menuapp.js';
import ElevatorMenu from './js/menu-elevator.js';


function App(props) {
  return (
    <>
      <meta name="viewport" content="initial-scale=1, width=device-width" />
      <MenuApp />
      <ElevatorMenu />
    </>
  );
} export default App;