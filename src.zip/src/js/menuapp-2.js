import * as React from 'react';
import {useEffect, useState} from "react";
import * as iolocal from './iolocal';
import * as Calc from './calc';
import * as inteface from './interface';
import PropTypes from 'prop-types';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import FormGroup from '@mui/material/FormGroup';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import Avatar from '@mui/material/Avatar';
import TextField from '@mui/material/TextField';
import { Stack } from '@mui/system';
import SettingsTwoToneIcon from '@mui/icons-material/SettingsTwoTone';
import * as Dialogs from './dialogs';

const drawerWidth = 240;

function ElevatorSelectMenu () {
  const [ElevatorName, SetElevatorName] = useState("");
  const handleChangeElevator = (event) => {
    SetElevatorName(event.target.value);
    console.log("ElevatorSelected = ", Calc.ElevatorSelected);
    console.log("Elevator = ", Calc.Elevators[Calc.ElevatorSelected]);
  };
  const handleClickElevatorMenu = (event, index) => {
    Calc.SetElevatorSelected(index);
  }

  return (
    <FormControl size="small" fullWidth >
          <InputLabel  >Elevator Name</InputLabel> 
            <Select value={ElevatorName} label="Elevator Name" onChange = {handleChangeElevator} >
              {iolocal.ElevatorList.map((name, index ) => (
                <MenuItem key={index} value={ name } onClick={ (event) => handleClickElevatorMenu(event, index) }>
                { index + ". " +  name}
                </MenuItem>
              ))}
            </Select>
        </FormControl>
  );
};

function DrawerAppBar(props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const [anchorElFileMenu, setAnchorElFileMenu] = React.useState(null);


  const handleDrawerToggle = () => {
    if (iolocal.ElevatorOpened) {
        setMobileOpen((prevState) => !prevState);
      } else alert("Local DB not Opened");
  };

  const handleOpenFileMenu = (event) => {
    setAnchorElFileMenu(event.currentTarget);
  };

  const handleCloseFileMenu = () => {
    setAnchorElFileMenu(null);
  };

  const handleClickFileMenu = ( index ) => {
    //setSelectedIndex(index);
    setAnchorElFileMenu(null);
    if ( index == 0 ) iolocal.NewWarehouse();
    if ( index == 1 ) iolocal.OpenWarehouse();
    if ( index == 2 ) iolocal.SaveWarehouse(Calc.Elevators);
    if ( index == 3 ) iolocal.ImportWarehouse();
    if ( index == 4 ) iolocal.ExportWarehouse();
  };


  const drawer = (
    <Box sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 0  }}>
        Elevator Select
      </Typography>
      <Divider />
      <Typography variant="h3" sx={{ my: 2  }}>
        <ElevatorSelectMenu/>
        <FormControl size="small" fullWidth >
          <InputLabel  >Warehouse Name</InputLabel> 
            <Select label="Warehouse Name">
              {iolocal.WarehouseList.map((name, index ) => (
                <MenuItem key={index} value={ name } >
                { index + ". " +  name}
                </MenuItem>
              ))}
            </Select>
        </FormControl>
        <FormControl size="small" fullWidth >
          <InputLabel  >Pile Name</InputLabel> 
            <Select label="Pile Name">
              {iolocal.PileList.map((name, index ) => (
                <MenuItem key={index} value={ name } >
                { index + ". " +  name}
                </MenuItem>
              ))}
            </Select>
        </FormControl>
        </Typography>
      <List onClick={handleDrawerToggle}>
          <ListItem disablePadding>
            <ListItemButton>
              <ListItemText primary="чё-то" />
            </ListItemButton>
          </ListItem>
      </List>
    </Box>
  );

  const container = window !== undefined ? () => window().document.body : undefined;

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar component="nav">
        <Toolbar>
        <Tooltip title="Elevator Select Menu">
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          </Tooltip>
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1 }}
          >
            Elevators
          </Typography>
          
          <Box sx={{ flexGrow: 0 }}>
            <Tooltip title="File Operation">
              <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="start"
                onClick={handleOpenFileMenu}
                sx={{ mr: 2 }}
              >
            <MenuIcon />
          </IconButton>
            </Tooltip>
            <Menu
              sx={{ mt: '45px' }}
              id="menu-appbar"
              anchorEl={anchorElFileMenu}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={Boolean(anchorElFileMenu)}
              onClose={handleCloseFileMenu}
            >
              <MenuItem key={0} onClick={() => handleClickFileMenu( 0 ) }>
                  <Typography textAlign="center">New Local DB</Typography>
              </MenuItem>
              <Divider/>
              <MenuItem key={1} onClick={() => handleClickFileMenu( 1 ) }>
                  <Typography textAlign="center">Open Local DB</Typography>
              </MenuItem>
              <MenuItem key={2} onClick={() => handleClickFileMenu( 2 ) }>
                  <Typography textAlign="center">Save Local DB</Typography>
              </MenuItem>
              <Divider/>
              <MenuItem key={3} onClick={() => handleClickFileMenu( 3 ) }>
                  <Typography textAlign="center">Import from File</Typography>
              </MenuItem>
              <MenuItem key={4} onClick={() => handleClickFileMenu( 4 ) }>
                  <Typography textAlign="center">Export to File</Typography>
              </MenuItem>
            </Menu>
          </Box>

        </Toolbar>
      </AppBar>
      <Box component="nav">
        <Drawer
          container={container}
          variant="temporary"   
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
          sx={{ '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
      </Box>
      <ElevatorMenuEdit/>
    </Box>
  );
}

function ElevatorMenuEdit () {
  //const [value_ElevatorName, set_ElevatorName] = useState();
  //useEffect(() => {
  //    Calc.SetElevatorName(Calc.ElevatorSelected, value_ElevatorName)
  //  }, [value_ElevatorName]);

  return (
      <Box component="main" sx={{ p: 0 }}>
        <Toolbar />
        <Typography sx={{ p: 1 }}>
          <TextField
            onDoubleClick = {() => alert("Clicked!")}
            //onChange={(event) => set_ElevatorName(event.target.value)}
            value={Calc.Elevators[Calc.ElevatorSelected].Name}
            label="Название элеватора"
            sx={{ p: 1 }}
            helperText="Изменить название?"
            FormHelperTextProps={{
            onClick: () => alert("Clicked!")
            }}
            InputProps={{ readOnly: true,
              endAdornment:
                <IconButton color="primary" aria-label="Edit Elevator Name" component="label" onClick={() => { Dialogs.ElevatorDialogShow(Calc.Elevators[Calc.ElevatorSelected].Name, Calc.ElevatorSelected) }}>
                  <Tooltip title="Edit Elevator Name">
                    <SettingsTwoToneIcon />
                  </Tooltip>
                </IconButton> }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Date}
            label="Дата инспекции"
            sx={{ p: 1 }}
            type = 'date'
          />
          <Box/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Place}
            label="Адресс"
            fullWidth 
            sx={{ p: 1 }}
          />
          <br/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Owner}
            label="Владелец элеватора"
            sx={{ p: 1 }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Client}
            label="Клиент по залогу"
            sx={{ p: 1 }}
          />
          <br/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].ContactName}
            label="Контактное лицо"
            sx={{ p: 1 }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].ContactPosition}
            label="Должность"
            sx={{ p: 1 }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].ContactPhone}
            label="Телефон"
            sx={{ p: 1 }}
          />
          <br/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].ElevatorSilo.length}
            label="Бетонные силоса"
            sx={{ p: 1 }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Silo.length}
            label="Силоса"
            sx={{ p: 1 }}
          />
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Warehouse.length}
            label="Напольные склады"
            sx={{ p: 1 }}
          />
          <br/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].InspectorName}
            label="Инспектор"
            fullWidth
            sx={{ p: 1 }}
          />
          <br/>
          <TextField
            value={Calc.Elevators[Calc.ElevatorSelected].Comments}
            label="Комментарий"
            fullWidth
            sx={{ p: 1 }}
          />
        </Typography>
      </Box>
  );
}

DrawerAppBar.propTypes = {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

export default DrawerAppBar;
