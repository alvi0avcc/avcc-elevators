import * as React from 'react';
import {useEffect, useState} from "react";
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import SettingsTwoToneIcon from '@mui/icons-material/SettingsTwoTone';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select'
import * as Dialogs from './dialogs';
import { Elevators } from './elevators.js';


function ElevatorSelectMenu () {
    const [ElevatorName, SetElevatorName] = useState("");
    const handleChangeElevator = (event) => {
            SetElevatorName(event.target.value);
        };
    const handleClickElevatorMenu = (event, index) => {
            Elevators.Selected = index;
        }

    //useEffect(() => {
    //    if ( Elevators.Elevators.length > 0 ) { SetElevatorName (Elevators.Elevators[0].Name) }
    //  }, [Elevators.State]);

    return (
      <FormControl size="small" fullWidth >
            <InputLabel  >Elevator Name</InputLabel> 
              <Select value={ElevatorName} label="Elevator Name" onChange = {handleChangeElevator} >
                {Elevators.ElevatorList().map((name, index ) => (
                  <MenuItem key={index} value={ name } onClick={ (event) => handleClickElevatorMenu(event, index) }>
                  { index + ". " +  name}
                  </MenuItem>
                ))}
              </Select>
          </FormControl>
    );
  };

export default function ElevatorMenu () {
    const [value_ElevatorName, set_ElevatorName] = useState();
    //useEffect(() => {
    //    Calc.SetElevatorName(Calc.ElevatorSelected, value_ElevatorName)
    //  }, [value_ElevatorName]);
    //if ( Elevators.Elevators.length > 0 ) {
    //    set_ElevatorName(Elevators.Elevators[Elevators.Selected])
   // }
    //if ( Elevators.Elevators.length > 0 ) { set_ElevatorName (Elevators.Elevators[0].Name) }
    return (
        <Box component="main" sx={{ p: 2 }}>
            <ElevatorSelectMenu/>
            <TextField
              //onDoubleClick = {() => alert("Clicked!")}
              onChange={() => set_ElevatorName(Elevators.name)}
              value={value_ElevatorName}
              label="Название элеватора"
              sx={{ p: 1 }}
              InputProps={{ 
                endAdornment:
                  <IconButton color="primary" aria-label="Edit Elevator Name" component="label" onClick={() => { Dialogs.ElevatorDialogShow('', 0) }}>
                    <Tooltip title="Edit Elevator Name">
                      <SettingsTwoToneIcon />
                    </Tooltip>
                  </IconButton> }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Date}
              label="Дата инспекции"
              sx={{ p: 1 }}
              type = 'date'
            />
            <Box/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Place}
              label="Адресс"
              fullWidth 
              sx={{ p: 1 }}
            />
            <br/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Owner}
              label="Владелец элеватора"
              sx={{ p: 1 }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Client}
              label="Клиент по залогу"
              sx={{ p: 1 }}
            />
            <br/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].ContactName}
              label="Контактное лицо"
              sx={{ p: 1 }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].ContactPosition}
              label="Должность"
              sx={{ p: 1 }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].ContactPhone}
              label="Телефон"
              sx={{ p: 1 }}
            />
            <br/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].ElevatorSilo.length}
              label="Бетонные силоса"
              sx={{ p: 1 }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Silo.length}
              label="Силоса"
              sx={{ p: 1 }}
            />
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Warehouse.length}
              label="Напольные склады"
              sx={{ p: 1 }}
            />
            <br/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].InspectorName}
              label="Инспектор"
              fullWidth
              sx={{ p: 1 }}
            />
            <br/>
            <TextField
              //value={Calc.Elevators[Calc.ElevatorSelected].Comments}
              label="Комментарий"
              fullWidth
              sx={{ p: 1 }}
            />
        </Box>
    );
  }