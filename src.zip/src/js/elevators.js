
 export function SetElevators (props) { Elevators.Elevators = props; };
 

class cElevatorSilo {
    constructor() {
    this.Name   ='';
    this.Bunker =[{name: '', D: 0, H: 0, Sound: 0 }]
    }
};


class cSilo {
    constructor() {
        this.Name       = '';
        this.Dimensions = {Diameter: 0, H: 0, h: 0, Sound: 0 };
        this.Ullage     = 0;
        this.Cargo      = {Name: '', Natura: 1 };
        this.Comments   = ''
    }
};

class cPile {
    constructor() {
            this.dx1 = 21.76;
            this.dy1 = 18.02;
            this.dh1 = 0.6;
            this.dx2 = 17.82;
            this.dy2 = 18.02;
            this.dh2 = 3.06;
            this.ux  = 11.03;
            this.uy  = 2.84
        }
    }

class cWarehouse {
    constructor() {
    this.Name        = '';
    this.Dimensions  = {Length: 0, Width: 0, Height: 0 };
    this.Pile        = [];
    this.Cargo       = {Name: '', Natura: 1 };
    this.Comments    = ''
    }
};


class cElevator {
    constructor() {
        this.id      = '';
        this.Name    = '';
        this.Place   = '';
        this.Adress  = '';
        this.Owner   = '';
        this.GEO     = '';
        this.ContactName     = '';
        this.ContactPosition = '';
        this.ContactPhone    = '';
        this.Date            = '';
        this.InspectorName   = '';
        this.Client          = '';
        this.Silo            = [];
        this.Warehouse       = [];
        this.ElevatorSilo    = [];
        this.Comments        = ''       
        }
        AddESilo(){
            this.Silo.push(new cSilo());
            this.State = 'changed'
        }

    };

class cElevators {
    constructor() {
        this.State = "closed";
        this.Selected = 0;
        this.Elevators = []
    }
    get name(){
        if ( this.Elevators.length > 0 ) {return this.Elevators[this.Selected].Name}
        else return "empty"
    }
    AddElevator(){
        this.Elevators.push(new cElevator());
        this.State = 'changed'
    }
    ElevatorList(){
        let ElevatorList = [];
        let ii = Elevators.Elevators.length;
        let data;
        if (ii > 0 ) {    
            for( let i =0 ; i < ii ; i++){
                data = i + Elevators.Elevators[i].id + Elevators.Elevators[i].Name;
                ElevatorList.push( data );
            }
        }
        console.log('ElevatorList = ', ElevatorList)
        return(
            ElevatorList
        )
    }
};

export let Elevators = new cElevators();

