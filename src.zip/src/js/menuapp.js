import * as React from 'react';
import * as iolocal from './iolocal';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import MenuItem from '@mui/material/MenuItem';
import AdbIcon from '@mui/icons-material/Adb';

const FileMenu = ['Create/Add', 'Open', 'Save', 'Import', 'Export'];

function ResponsiveAppBar() {
  const [anchorElFile, setAnchorElFile] = React.useState(null);

  const handleOpenFileMenu = (event) => {
    setAnchorElFile(event.currentTarget);
  };

  const handleCloseFileMenu = () => {
    setAnchorElFile(null);
  };

  const handleClickFileMenu = ( index ) => {
    console.log(index);
    if ( index == FileMenu[0] ) iolocal.NewElevator();
    if ( index == FileMenu[1] ) iolocal.OpenElevator();
    if ( index == FileMenu[2] ) iolocal.SaveElevator();
    if ( index == FileMenu[3] ) iolocal.ImportWarehouse();
    if ( index == FileMenu[4] ) iolocal.ExportWarehouse();
    setAnchorElFile(null);
  };

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Box sx={{ flexGrow: 1 }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenFileMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElFile}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElFile)}
              onClose={handleCloseFileMenu}
            >
              {FileMenu.map((page) => (
                <MenuItem key={page} onClick={() => handleClickFileMenu(page)}>
                  <Typography textAlign="center">{page}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
          <Typography
            variant="h5"
            noWrap
            component="a"
            href=""
            sx={{
              mr: 2,
              flexGrow: 1,
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            Elevators
          </Typography>
        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default ResponsiveAppBar;