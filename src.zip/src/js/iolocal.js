import * as React from 'react';
import { Elevators, SetElevators } from './elevators.js';
import Button from '@mui/material/Button';
import {AlertUpper} from './interface.js';
import { render } from '@testing-library/react';
import root from '../index.js';
//import { Warehouse } from './calc.js';
//import {FJ} from './calc.js';

export let ElevatorOpened = false; // Local BD Opened/Closed


let FileSel = React.createRef();
let FileWork;
let FileJSON;
//let FJ;
//import ListItem from "../classes/ListItem";
let ElevatorKey = ''; //ключ текущего элеватора в localStorage
export let ElevatorList = [];
export let WarehouseList = [];
export let PileList = [];

export function NewElevator(props) {
    if ( localStorage.getItem("Elevator") ) { 
        Elevators.AddElevator();
        Elevators.State = 'changed';
        console.log("New Empty Elevator Added !")
    } else {
        Elevators.AddElevator();
        Elevators.State = 'changed';
        localStorage.setItem( "Elevator" , JSON.stringify(Elevators.Elevators));
        console.log("New Empty Elevator Created !")
        };
    return(
        console.log('Elevators after Create/Add ',Elevators)
    );
}

export function ElevatorListGet () {
   // let ii = Calc.Elevators.length;
   let ii = 0;
    let data;
    ElevatorList = [];
    for( let i =0 ; i < ii ; i++){
        //data = Calc.Elevators[i].id + Calc.Elevators[i].Name;
        ElevatorList.push( data );
        //console.log("data" , data);
    };
    console.log("ElevatorList", ElevatorList);
}

export function OpenElevator() {
    let data = localStorage.getItem("Elevator");
    if ( data ) {
        SetElevators(JSON.parse(data));
        Elevators.State = 'open'
    } else {
                Elevators.State = 'closed'
                alert ("Локальная БД пуста!");
            }
    return(
        console.log( Elevators )
    );
};

export function SaveElevator() {
    localStorage.setItem("Elevator", JSON.stringify(Elevators.Elevators));
};

function ImportWarehouse(props) {
    return(
        alert('Import')
    );
} export {ImportWarehouse};

function ExportWarehouse(props) {
    return(
        FileSave(props)
    );
} export {ExportWarehouse};

function FileInputButton(props) {
    return (
        <Button variant="outlined" component="label" >
            Open Local File
            <input ref={FileSel} hidden accept=".json" type="file" onChange={() => {FileInput()}}/>
        </Button> 
    );
    } export {FileInputButton};   

function FileInput(props) {
        let reader = new FileReader();
        FileWork = FileSel.current.files[0];
        reader.addEventListener('progress', (event) => {
            if (event.loaded && event.total) {
              const percent = (event.loaded / event.total) * 100;
              console.log(`Progress: ${Math.round(percent)}`);
            }
          });  
        reader.onload = function() {
            FileJSON = JSON.parse(reader.result);
            console.log("File loaded (inside)",FileWork.name, FileJSON);
            JsonToWarehouse();
        };
        reader.readAsText(FileWork);    
    return (null);
}export {FileInput};


function FileSave (props) {
    //WarehouseToJSON();
    //if ( Calc.Elevator.Name || null ) 
    //{
    //    console.log(Calc.Elevator);
        //let data = JSON.stringify(Calc.Elevator);
        //let name = Calc.Elevator.Name + Calc.Elevator.Date;
    //    let a=document.createElement("a")
    //    console.log("File save",name);
    //    a.setAttribute("download", name||"Elevator.json");
    //    a.setAttribute("href", "data:application/octet-stream;base64,"+btoa(data||"undefined"));
    //    a.click();
    //    setTimeout(() => {
    //        URL.revokeObjectURL(a.href);
    //        a.remove();
    //        }, 1000);
    //} else { alert("No data for Export!")};
  }

function WarehouseToJSON () {
    //FileJSON = Warehouse;
} export {WarehouseToJSON};

function JsonToWarehouse () {
 //           Warehouse.InspectionClient = FileJSON.InspectionClient;
 //           Warehouse.InspectionDate = FileJSON.InspectionDate;
 //           Warehouse.InspectionPlace = FileJSON.InspectionPlace;
 //           Warehouse.InspectorName = FileJSON.InspectorName;
 //           Warehouse.Piles = FileJSON.Piles;
    return (console.log("Warehouse readed"
    //Warehouse
    ));
} 