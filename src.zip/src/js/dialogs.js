import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import * as Calc from "./calc";
import { ElevatorListGet } from "./iolocal";

export function ElevatorDialogShow (name, index) {
    let NewName = "";
    //let data = Elevators[index];
    //console.log("name = ", name);
    //console.log("index = ", index);
    //console.log("Elevators = ", Elevators[index]);
    //console.log("data = ", data);
       NewName = prompt("New Name of Elevator", name );
    if ( NewName || "" ) {
      //data.Name = NewName;
      //console.log("data = ", data);
      //Calc.SetElevatorName(index, NewName);
      //ElevatorListGet();
    };
  };